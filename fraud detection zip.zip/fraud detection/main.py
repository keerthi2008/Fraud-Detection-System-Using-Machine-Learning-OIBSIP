import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
import seaborn as sns
# loard dataset.
df=pd.read_excel("fraud_detection_dataset.xlsx")
print(df.head())
# understand data 
print(df.info())
print(df.describe())
print(df['fraud_flag'].value_counts())
#data cleaning 
df.isnull().sum()
df.drop_duplicates(inplace=True)
# feature engineering
df['high_amount']=df['amount'].apply(lambda x:1 if x>5000 else 0)
df['risk']=df.apply(lambda x:"high" if x['amount']>7000 and x['is_international']=="yes" else "low", axis=1)
# convert categorial to numbers 
df=pd.get_dummies(df,drop_first=True)
#split data
from sklearn.model_selection import train_test_split
x=df.drop('fraud_flag',axis=1)
y=df['fraud_flag']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)
#train model
from sklearn.linear_model import LogisticRegression
model=LogisticRegression(max_iter=2000,class_weight='balanced')
model.fit(x_train,y_train)
#prediction
y_pred=model.predict(x_test)
#evalutation
from sklearn.metrics import accuracy_score,confusion_matrix
print("accuarcy",accuracy_score(y_test,y_pred))
print(confusion_matrix(y_test,y_pred))
#visualization

#fraud vs normal
sns.countplot(x='fraud_flag',data=df)
plt.title("fraud  vs  normal")
plt.show()

#fraud  by  transaction type
sns.countplot(x='transaction_type_online',hue='fraud_flag',data=df)
plt.show()
# decesion tree
from sklearn.tree import DecisionTreeClassifier
#initialize and train the decision tree
dt_model=DecisionTreeClassifier(criterion='entropy',max_depth=5)
dt_model.fit(x_train,y_train)
#make prediction
dt_pred=dt_model.predict(x_test)
#evaluating the perdormance 
print ("decision tree accuarcy:",accuracy_score(y_test,y_pred))
print("decision tree confusion matrix :")
print(confusion_matrix(y_test,dt_pred))
#random forest
from sklearn.ensemble import RandomForestClassifier
